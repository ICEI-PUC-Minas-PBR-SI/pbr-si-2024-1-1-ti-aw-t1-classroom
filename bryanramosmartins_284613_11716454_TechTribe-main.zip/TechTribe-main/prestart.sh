# SPDX-FileCopyrightText: 2023 
#
# SPDX-License-Identifier: MPL-2.0

alembic upgrade head
