<!--
SPDX-FileCopyrightText: 2023 

SPDX-License-Identifier: MPL-2.0
-->
Welcome to the TechTribe community

Grant and indulge critique constructively, within desired privacy.
Settle disputes within these confines.
Finding yourselves unable, e-mail hi@militão.eu answered by Marlon (Militão), the project maintainer.
